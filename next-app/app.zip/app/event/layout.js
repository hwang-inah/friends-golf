export const metadata = {
  title: "이벤트",
  description: "프렌즈프리미엄 골프연습장 이벤트 및 프로모션 정보",
};

export default function EventLayout({ children }) {
  return children;
}
