export const metadata = {
  title: "소개",
  description: "프렌즈프리미엄 골프연습장 신불당점 소개 - 프리미엄 타석, 전문 프로 레슨, 키즈 맞춤 레슨",
};

export default function AboutLayout({ children }) {
  return children;
}
