export const metadata = {
  title: "프로진 소개",
  description: "프렌즈프리미엄 골프연습장 전문 프로진 소개 - 10년 이상 경력의 프로가 책임 지도",
};

export default function ProsLayout({ children }) {
  return children;
}
