import EmptyState from '../../src/components/molecules/EmptyState/EmptyState.jsx'

export default function ProductsPage() {
  return <EmptyState />
}
