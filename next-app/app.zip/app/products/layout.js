export const metadata = {
  title: "상품",
  description: "프렌즈프리미엄 골프연습장 레슨 상품 및 패키지 안내",
};

export default function ProductsLayout({ children }) {
  return children;
}
