export const metadata = {
  title: "갤러리",
  description: "프렌즈프리미엄 골프연습장 갤러리 - 레슨 Before & After, 시설 사진",
};

export default function GalleryLayout({ children }) {
  return children;
}
