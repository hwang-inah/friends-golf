'use client'

import { useState } from 'react'
import KakaoMapScript from './KakaoMapScript.jsx'
import LocationContent from '../../src/components/organisms/LocationContent/LocationContent.jsx'

export default function LocationPage() {
  const [kakaoReady, setKakaoReady] = useState(false)
  const [kakaoFailed, setKakaoFailed] = useState(false)

  const handleScriptLoad = () => {
    if (typeof window !== 'undefined' && window.kakao && window.kakao.maps) {
      setKakaoReady(true)
    }
  }

  const handleScriptError = (error) => {
    console.error('카카오맵 스크립트 로드 실패:', error)
    setKakaoFailed(true)
  }

  return (
    <>
      <KakaoMapScript onLoad={handleScriptLoad} onError={handleScriptError} />
      <LocationContent kakaoReady={kakaoReady} kakaoFailed={kakaoFailed} />
    </>
  )
}
