'use client'

import Script from 'next/script'

const KakaoMapScript = ({ onLoad, onError }) => {
  const kakaoMapKey = process.env.NEXT_PUBLIC_KAKAO_MAP_API_KEY || 'ad2e572104405d8f84055acbf8b5df9e'

  return (
    <Script
      src={`https://dapi.kakao.com/v2/maps/sdk.js?appkey=${kakaoMapKey}&autoload=false`}
      strategy="afterInteractive"
      onLoad={onLoad}
      onError={onError}
    />
  )
}

export default KakaoMapScript
