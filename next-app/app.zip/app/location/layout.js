export const metadata = {
  title: "오시는 길",
  description: "프렌즈프리미엄 골프연습장 신불당점 위치 및 오시는 길 안내",
};

export default function LocationLayout({ children }) {
  return children;
}
