// 시설 슬라이드 이미지 (마스터)
export const facilitySlides = [
  {
    id: 1,
    image: '/images/facility/facility501.jpg',
  },
  {
    id: 2,
    image: '/images/facility/facility503.jpg',
  },
  {
    id: 3,
    image: '/images/facility/facility402.jpg',
  },
  {
    id: 4,
    image: '/images/facility/facility403.jpg',
  },
  {
    id: 5,
    image: '/images/facility/facility405.jpg',
  }
]